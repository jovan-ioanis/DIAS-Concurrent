package protocols;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import communication.DIASMessType;

import dsutil.protopeer.services.aggregation.AggregationFunction;
import protopeer.measurement.LogReplayer;
import protopeer.measurement.MeasurementLog;

public class DIASanalyzer {
	
	private static final String expSeqNum="01";
    private static final String expID="Experiment "+expSeqNum+"/";
    private static final String path = "peersLog/"+expID;
    private static final int numOfEpochs = 250;
    
    private LogReplayer replayer;
    private int minEpochNum;
    private int maxEpochNum;
    private File[] listOfFiles;
    private int numOfEpochsToConverge = 0;
    private double stdDeviationConvergence = 0.0;
    
    private PrintWriter out;
    private boolean startingPrinted = false;
    
    Set<Integer> setofAggregatorsON = new HashSet<Integer>();
    
    public DIASanalyzer(int minEpochNum, int maxEpochNum) {
    	this.minEpochNum = minEpochNum;
    	this.maxEpochNum = maxEpochNum;
    	this.replayer = new LogReplayer();    
    	try {
			out = new PrintWriter(new BufferedWriter(new FileWriter("report2.txt", true)));
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    public static void main(String args[]) {
    	DIASanalyzer analyzer = new DIASanalyzer(0, numOfEpochs);
    	analyzer.loadFiles();
    	System.out.println("Loaded Files!");
    	analyzer.analyze();
    }

   
    public void loadFiles() {
    	try {
    		File folder = new File(path);
    		listOfFiles = folder.listFiles();
    	}
    	catch(Exception e) {
    		System.out.println("None files were found on path: " + path);
    	}
    }
    
    public void analyze() {
    	System.out.println("Calculating std deviation...");  
    	System.out.println("============================================ AVG =================================================");
    	calculateStdDeviation1(AggregationFunction.AVG);
    	System.out.println("============================================ MAX =================================================");
    	calculateStdDeviation1(AggregationFunction.MAX);
    	System.out.println("========================================= MSG COUNT ==============================================");
    	countMessages();
    	printOut();
    	
    }
    
//    public void printOut() {
//    	for(int i = 0; i < listOfFiles.length; i++) {
//    		try {
//    			
//				MeasurementLog loadedLog=replayer.loadLogFromFile(path+listOfFiles[i].getName());
//				StringBuilder sb = new StringBuilder();
//				sb.append("AVG: " + loadedLog.getAggregate(AggregationFunction.AVG).getAverage());
//				sb.append("\t");
//				sb.append("MAX: " + loadedLog.getAggregate(AggregationFunction.MAX).getAverage());
//				System.out.println(sb.toString());
//				
//			} catch (ClassNotFoundException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//    	}    	
//    }
    
    private void calculateStdDeviation(Object tag) {
    	int numOfNodes = listOfFiles.length;
    	ArrayList<Double> averageList = new ArrayList<Double>();
    	ArrayList<Double> sumList = new ArrayList<Double>();
    	ArrayList<Double> sumSquaredDiffList = new ArrayList<Double>();
    	ArrayList<ArrayList<Double>> valuesList = new ArrayList<ArrayList<Double>>();
    	ArrayList<Double> stdDeviation = new ArrayList<Double>();
    	
    	/*for(int i = 0; i < maxEpochNum; i++) {
    		valuesList.add(new ArrayList<Double>());
    	}
    	
    	for(int i = 0; i < numOfNodes; i++) {
    		for(int j = 0; j < maxEpochNum; j++) {
    			try {
    				
					MeasurementLog loadedLog=replayer.loadLogFromFile(path+listOfFiles[i].getName());
					double value = loadedLog.getAggregateByEpochNumber(j, tag).getSum();
					valuesList.get(j).add(i, value);
					
				} catch (ClassNotFoundException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    	}*/
    	
    	for(int j = minEpochNum; j < maxEpochNum; j++) {
    		// Calculating results per epoch
    		valuesList.add(j, new ArrayList<Double>());
    		double sum = 0;
    		for(int i = 0; i < numOfNodes; i++) {
    			// for each node get values for current epoch
    			try {   
    				// getting value from the file
    				MeasurementLog loadedLog=replayer.loadLogFromFile(path+listOfFiles[i].getName());
    				//System.err.println("path was ok!");
    				double value = loadedLog.getAggregateByEpochNumber(j, tag).getSum();
    				//System.out.println("reading was ok");
    				// calculate sum of all values 
    				//if(!valuesList.get(j).isEmpty()) {
    					sum = sum + value;
    				//}
    				if(valuesList.get(j) == null) {
    					valuesList.add(new ArrayList<Double>());
    				}
    				// store values
    				valuesList.get(j).add(value);
    			}
    			catch (Exception e) {
    				System.out.println("Exception while reading file!!");
    				e.printStackTrace();
    			}
    		}
    		// store sum 
    		sumList.add(j, sum);
    		// store avg
    		averageList.add(j, sumList.get(j)/numOfNodes);
    		ArrayList<Double> epochValues  = valuesList.get(j);
    		//if(!epochValues.isEmpty()) {
    			double sumSqDiff = 0;
        		for(int k = 0; k < numOfNodes; k++) {
        			double val1 = epochValues.get(k) - averageList.get(j);
        			double val = Math.pow(val1, 2);
        			sumSqDiff += val;
        		}
        		sumSquaredDiffList.add(j, sumSqDiff/sumList.get(j));
    		//}
    		//else {
    			//sumSquaredDiffList.add(j, 0.0);
    		//}
    		
    		stdDeviation.add(j, Math.sqrt(sumSquaredDiffList.get(j)/sumList.get(j)));
    	}
    	
    	System.out.println("\nResults of standard deviation of " +  tag +  " value of all nodes per epoch number!\n");
    	printValues(stdDeviation);    	
    }
    
    public void printValues(ArrayList list) {
    	for(int i = 0; i < list.size(); i++) {
    		System.out.println("epoch num: " + i + "\tStd Deviation: " + list.get(i));
    	}
    }
    
    public void calculateStdDeviation1(Object tag) {
    	
    	ArrayList<ArrayList<Double>> valueList = new ArrayList<ArrayList<Double>>();
    	// each entry is information about each epoch
    	ArrayList<Double> sumList = new ArrayList<Double>();
    	ArrayList<Double> avgList = new ArrayList<Double>();
    	ArrayList<Double> sumSqrDiffList = new ArrayList<Double>();
    	ArrayList<Double> stdDeviationList = new ArrayList<Double>();
    	ArrayList<Double> activeAggregatorCountList = new ArrayList<Double>();
    	ArrayList<ArrayList<Boolean>> isAggregatorActivePerEpoch = new ArrayList<ArrayList<Boolean>>();
    	
    	for(int k = minEpochNum; k < maxEpochNum; k++) {
    		activeAggregatorCountList.add(k, 0.0);
    	}
    	
    	for(int i = 0; i < listOfFiles.length; i++) {
    		valueList.add(i, new ArrayList<Double>());
    		isAggregatorActivePerEpoch.add(i, new ArrayList<Boolean>());
    		
    		try {
    			
				MeasurementLog loadedLog=replayer.loadLogFromFile(path+listOfFiles[i].getName());
				ArrayList<Double> list = valueList.get(i);
				for(int j = minEpochNum; j < maxEpochNum; j++) {
					double value = loadedLog.getAggregateByEpochNumber(j, tag).getSum();
					double on_off = loadedLog.getAggregateByEpochNumber(j, "ON_OFF").getSum();
					//System.out.println(on_off);
					if(on_off == 1.0) {
						double count = activeAggregatorCountList.remove(j);
						count +=1;
						activeAggregatorCountList.add(j, count);
						setofAggregatorsON.add(i);
						isAggregatorActivePerEpoch.get(i).add(j, true);
					}
					else /*if(on_off == -1.0)*/ {
						isAggregatorActivePerEpoch.get(i).add(j, false);
					}
					list.add(j, value);
				}
				
			} catch (ClassNotFoundException e) {				
				e.printStackTrace();
			} catch (IOException e) {				
				e.printStackTrace();
			}    		
    	}
    	
    	numOfEpochsToConverge = 0;
    	stdDeviationConvergence = 0.0;
    	
    	for(int i = minEpochNum; i < maxEpochNum; i++) {
    		double sum = 0;
    		for(int j = 0; j < listOfFiles.length; j++) {
    			if(isAggregatorActivePerEpoch.get(j).get(i) == true) {
    				//System.out.println("USAO");
    				sum += valueList.get(j).get(i);
    			}    			
    		}
    		sumList.add(i, sum);
    		avgList.add(i, sumList.get(i)/activeAggregatorCountList.get(i));
    		double sumDiffSqr = 0;
    		for(int j = 0; j < listOfFiles.length; j++) {
    			if(isAggregatorActivePerEpoch.get(j).get(i) == true) {
    				sumDiffSqr += Math.pow(valueList.get(j).get(i) - avgList.get(i), 2);
    			}
    		}
    		sumSqrDiffList.add(i, sumDiffSqr);
    		stdDeviationList.add(i, Math.sqrt(sumSqrDiffList.get(i)/sumList.get(i)));
    		System.out.println("epoch " + i + ":\t" + stdDeviationList.get(i));
    		
    		if(i > minEpochNum) {
    			if(!stdDeviationList.get(i-1).equals(Double.NaN) && !stdDeviationList.get(i).equals(Double.NaN) && !stdDeviationList.get(i-1).equals(stdDeviationList.get(i))) {
    				//System.out.println("prev: " + stdDeviationList.get(i-1) + " current: " + stdDeviationList.get(i));
    				numOfEpochsToConverge++;
    				stdDeviationConvergence = stdDeviationList.get(i);
    			}
    		}    		
    	}
    	System.out.println("Number of epochs necessary for system to converge is: " + numOfEpochsToConverge);
    	System.out.println("Number of Aggregators that were turned on is: " + setofAggregatorsON.size());
    	printStarting();
    	addToReport();
    }
    
    public void countMessages() {
    	ArrayList<ArrayList<Double>> pushMsgList = new ArrayList<ArrayList<Double>>();
    	ArrayList<ArrayList<Double>> pullMsgList = new ArrayList<ArrayList<Double>>();
    	ArrayList<Double> sumPushMsg = new ArrayList<Double>();
    	ArrayList<Double> sumPullMsg = new ArrayList<Double>();
    	
    	for(int i = 0; i < listOfFiles.length; i++) { 
    		pushMsgList.add(i, new ArrayList<Double>());
    		pullMsgList.add(i, new ArrayList<Double>());
    		try {    			
    			MeasurementLog loadedLog=replayer.loadLogFromFile(path+listOfFiles[i].getName());
    			for(int j = minEpochNum; j < maxEpochNum; j++) {
    				pushMsgList.get(i).add(j, loadedLog.getAggregateByEpochNumber(j, DIASMessType.PUSH).getSum());
    				pullMsgList.get(i).add(j, loadedLog.getAggregateByEpochNumber(j, DIASMessType.PULL).getSum());
    			} 
    			
			} catch (ClassNotFoundException e) {					
				e.printStackTrace();
			} catch (IOException e) {					
				e.printStackTrace();
			}
    	}
    	double sumPushAll = 0.0;
    	double sumPullAll = 0.0;
    	
    	for(int i = minEpochNum; i < maxEpochNum; i++) {
    		double sumPush = 0.0;
    		double sumPull = 0.0;
    		
    		for(int j = 0; j < listOfFiles.length; j++) {
    			sumPush += pushMsgList.get(j).get(i);
    			sumPull += pullMsgList.get(j).get(i);
    		}
    		sumPushMsg.add(i, sumPush);
    		sumPullMsg.add(i, sumPull);
    		System.out.println("epoch: " + i + "\tsumPushMsg: " + sumPush + "\tsumPullMsg: " + sumPull);
    		sumPushAll += sumPush;
    		sumPullAll += sumPull;
    	}
    	
    	out.print(sumPushAll + "\t\t" + sumPullAll + "");      	
    }
    
    public void addToReport() {    	
    	out.print(numOfEpochsToConverge + "\t\t\t" + stdDeviationConvergence + "\t\t");
    }
    
    public void printStarting() {
    	if(!startingPrinted) {
    		out.print("" + setofAggregatorsON.size() + "\t\t\t");
    		startingPrinted = true;
    	}    	
    }
    
    public void printOut() {
    	out.println("");
    	out.flush();
    	out.close();
    }
    

}
