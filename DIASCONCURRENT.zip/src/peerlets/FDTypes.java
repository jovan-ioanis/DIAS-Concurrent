package peerlets;

public enum FDTypes {
	IDLE,
	IDLE1,
	IDLE2,
	ACTIVATE_AGGREGATOR
}
